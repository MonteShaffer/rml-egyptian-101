https://commons.wikimedia.org/wiki/File:Hieroglyphs_from_the_tomb_of_Seti_I.jpg


Chapter 3 should be sound wheel and meanings?

